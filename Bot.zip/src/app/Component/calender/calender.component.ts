import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';

@Component({
  selector: 'tcs-calender',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.css']
})
export class CalenderComponent implements OnInit {
  today = formatDate(new Date(), 'dd/MM/yy', 'en');
  items = [{}, {}, {}, {}, {}, {}, {}, {}, {}];
  constructor() {}

  ngOnInit() {}
}
