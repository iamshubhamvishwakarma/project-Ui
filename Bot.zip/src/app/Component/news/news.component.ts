import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'tcs-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  @Input()
  message;
  constructor() { }

  ngOnInit() {
  }

}
