import { Component, OnInit, Input, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Router, Route } from '@angular/router';
@Component({
  selector: 'tcs-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {
  @Output()
  buttonResposne = new EventEmitter();
  @Input()
  message;
  constructor(private router: Router) {}

  ngOnInit() {
    console.log('asds', this.message.payload[0]);
  }
  noClick() {
    this.buttonResposne.emit({ src: '1', msg: 'No' });
  }
  yesClick() {
    this.buttonResposne.emit({ src: '1', msg: 'Yes' });
  }
  showCalender() {
    console.log('showclicked');
    this.router.navigateByUrl('/cal');
  }
}
