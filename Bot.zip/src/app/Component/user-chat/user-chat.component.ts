import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'tcs-user-chat',
  templateUrl: './user-chat.component.html',
  styleUrls: ['./user-chat.component.css']
})
export class UserChatComponent implements OnInit {
@Input()
message;
  constructor() { }

  ngOnInit() {
  }

}
