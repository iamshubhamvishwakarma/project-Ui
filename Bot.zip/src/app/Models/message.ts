export class Message {
  constructor() {}
  isFromMe: boolean;
  message: any;
  type: string;
  payload: any;
}
