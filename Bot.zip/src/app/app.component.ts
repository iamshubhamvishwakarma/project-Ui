import { Component, OnInit } from '@angular/core';
import { BotServiceService } from './service/bot-service.service';
import { Message } from './Models/message';

@Component({
  selector: 'tcs-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Bot';
  usermsg = '';
  messages: any = [];
  terminalResultsDiv;
  constructor(private botService: BotServiceService) {}
  ngOnInit(): void {
    this.botService.getBotResponse('hi').subscribe(res => {
      console.log('response in ng on init', res);

      const multipleMessage = JSON.parse(JSON.stringify(res)).result
        .fulfillment;
      console.log(multipleMessage.messages.length);
      if (multipleMessage.messages.length > 0) {
        for (let i = 0; i < multipleMessage.messages.length; i++) {
          const jsObj = multipleMessage.messages[i];

          const fromBot = new Message();
          fromBot.isFromMe = false;
          if (jsObj.type === 0) {
            fromBot.type = 'bot';
            if (jsObj.speech.includes('calendar')) {
              fromBot.type = 'schedule';

              const jj = JSON.parse(JSON.stringify(jsObj.speech));
              fromBot.payload = JSON.parse(jj).calendar;
            }

            fromBot.message = jsObj.speech;
            this.messages.push(fromBot);
          } else if (jsObj.type === 2) {
            fromBot.type = 'chips';
            fromBot.message = jsObj.speech;
            this.messages.push(fromBot);
          }
        }
        console.log('data', this.messages);
      } else {
        console.log('no result');
      }

      this.scrollToBottomOfResults();
    });
  }
  scrollToBottomOfResults() {
    this.terminalResultsDiv = document.getElementById('message-list');
    this.terminalResultsDiv.scrollTop = this.terminalResultsDiv.scrollHeight;
  }
  chipsMsg($event) {
    console.log($event.msg);
    this.usermsg = $event.msg;
    const ss = { key: 'Enter' };

    this.send(ss);
  }

  send($event) {
    if ($event.key !== 'Enter') {
      return;
    }
    if (this.usermsg.trim() === '') {
      return false;
    }

    const sm = new Message();
    sm.isFromMe = true;
    sm.type = 'user';
    sm.message = this.usermsg;
    this.messages.push(sm);

    this.scrollToBottomOfResults();
    this.botService.getBotResponse(this.usermsg).subscribe(res => {
      console.log('response recived', res);
      const multipleMessage = JSON.parse(JSON.stringify(res)).result
        .fulfillment;

      if (multipleMessage.messages.length > 0) {
        for (let i = 0; i < multipleMessage.messages.length; i++) {
          const jsObj = multipleMessage.messages[i];
          console.log('jsObj', jsObj);
          const fromBot = new Message();
          fromBot.isFromMe = false;
          if (jsObj.type === 0) {
            fromBot.type = 'bot';
            if (jsObj.speech.includes('calendar')) {
              fromBot.type = 'schedule';
            }

            fromBot.message = jsObj.speech;
            this.messages.push(fromBot);
          } else if (jsObj.type === 2) {
            fromBot.type = 'chips';
            fromBot.message = jsObj.speech;
            this.messages.push(fromBot);
          }
        }
        console.log('data', this.messages);
      } else {
        console.log('no result');
      }
    });
    this.usermsg = '';
    console.log('message sent', this.usermsg);
  }
}
