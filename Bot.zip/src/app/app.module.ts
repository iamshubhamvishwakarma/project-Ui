import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WindowComponent } from './Component/window/window.component';
import { HttpClientModule } from '@angular/common/http';
import { UserChatComponent } from './Component/user-chat/user-chat.component';
import { NewsComponent } from './Component/news/news.component';
import { ScheduleComponent } from './Component/schedule/schedule.component';
import { BotChatComponent } from './Component/bot-chat/bot-chat.component';
import { WeatherComponent } from './Component/weather/weather.component';
import { CalenderComponent } from './Component/calender/calender.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    WindowComponent,
    UserChatComponent,
    NewsComponent,
    ScheduleComponent,
    BotChatComponent,
    WeatherComponent,
    CalenderComponent,
    HomeComponent
  ],
  imports: [BrowserModule, AppRoutingModule, FormsModule, HttpClientModule],
  providers: [],
  bootstrap: [HomeComponent]
})
export class AppModule {}
