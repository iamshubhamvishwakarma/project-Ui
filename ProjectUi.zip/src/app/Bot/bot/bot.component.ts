import { Component, OnInit } from '@angular/core';
import { faSms, faClosedCaptioning } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'UI-bot',
  templateUrl: './bot.component.html',
  styleUrls: ['./bot.component.scss']
})
export class BotComponent implements OnInit {
  faMessage = faSms;
  isOpen = false;
  constructor() {}

  toggleWindow(event) {
    console.log(event);
    if (this.isOpen) {
      this.isOpen = false;
      this.faMessage = faClosedCaptioning;
    } else {
      this.isOpen = true;
      this.faMessage = faSms;
    }
    console.log(this.isOpen);
  }
  ngOnInit() {}
}
