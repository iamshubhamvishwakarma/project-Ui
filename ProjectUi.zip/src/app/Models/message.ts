export class Message {
  isFromMe: boolean;
  message: any;
}
