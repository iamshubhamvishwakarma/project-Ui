import { Component, OnInit } from "@angular/core";
import { FetchService } from "../../Service/fetch.service";
@Component({
  selector: "UI-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  items: any;
  constructor(private fetchService: FetchService) {}

  ngOnInit() {
    this.fetchService.getItems().subscribe(data => {
      console.log(data);
      this.items = data;
    });
  }
}
