import { Component, OnInit } from "@angular/core";

@Component({
  selector: "UI-nav-bar",
  templateUrl: "./nav-bar.component.html",
  styleUrls: ["./nav-bar.component.scss"]
})
export class NavBarComponent implements OnInit {
  isSideNavOpen = false;
  constructor() {}

  ngOnInit() {}
  toggleSideNav($event) {
    this.isSideNavOpen = !this.isSideNavOpen;
  }
}
