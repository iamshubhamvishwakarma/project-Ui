import { Component, OnInit, Input, Output } from "@angular/core";

@Component({
  selector: "UI-side-nav",
  templateUrl: "./side-nav.component.html",
  styleUrls: ["./side-nav.component.scss"]
})
export class SideNavComponent implements OnInit {
  @Input()
  isSideNavOpen;
  
  constructor() {}

  ngOnInit() {}
}
