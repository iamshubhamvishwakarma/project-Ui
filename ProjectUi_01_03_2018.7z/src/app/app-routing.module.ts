import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { AboutComponent } from "./Home/about/about.component";
import { HomeComponent } from "./Home/home/home.component";
import { ProfileComponent } from "./Home/profile/profile.component";
import { WishlistComponent } from "./Home/wishlist/wishlist.component";

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "home", component: HomeComponent },
  { path: "profile", component: ProfileComponent },
  { path: "wishlist", component: WishlistComponent },
  { path: "about", component: AboutComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
