import { Component, ViewChild, ElementRef } from "@angular/core";

@Component({
  selector: "UI-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent {
  title = "ProjectUi";
  terminalResultsDiv;
  hideIntro;
  @ViewChild("#holder") descElementView: ElementRef;
  descViewHeight: number;

  constructor() {}

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    
  }
  scrolling($event) {
    this.descViewHeight = this.descElementView.nativeElement.offsetHeight;
    if (this.descViewHeight > 100) {
      console.log(this.descViewHeight);
    } else {
      console.log("dont know");
    }
    console.log(this.terminalResultsDiv.scrollTop);
  }
}
