import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'UI-product-grid-item',
  templateUrl: './product-grid-item.component.html',
  styleUrls: ['./product-grid-item.component.scss']
})
export class ProductGridItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
