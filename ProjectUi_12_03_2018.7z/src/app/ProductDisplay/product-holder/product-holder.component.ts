import { Component, OnInit } from "@angular/core";

@Component({
  selector: "UI-product-holder",
  templateUrl: "./product-holder.component.html",
  styleUrls: ["./product-holder.component.scss"]
})
export class ProductHolderComponent implements OnInit {
  categories = [
    { title: "Running", quantity: "1" },
    { title: "Gym", quantity: "5" },
    { title: "Soccor", quantity: "23" },
    { title: "Basketball", quantity: "100" },
    { title: "Football", quantity: "12" },
    { title: "Casual", quantity: "14" }
  ];
  filterBrandList = [];

  constructor() {}

  ngOnInit() {}
  filterList($event, index: number) {
    if ($event.srcElement.checked) {
      this.filterBrandList.push($event.target.value);
    } else {
      this.filterBrandList.splice(
        this.filterBrandList.indexOf($event.target.value),
        1
      );
    }
  }
}
