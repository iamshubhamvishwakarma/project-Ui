import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Util } from "../util/util";
import { Item } from "../Models/item";
import { from } from "rxjs";
 
@Injectable({
  providedIn: "root"
})
export class FetchService {
  apiUrl;
  constructor(private httpClient: HttpClient) {}
  
  getItems(params?) {
    if (!params) {
      this.apiUrl = "http://www.mocky.io/v2/5c6a96cd330000ab187f4bd6";
    }else{  
      this.apiUrl = params;
    }

    let req = this.httpClient.get(this.apiUrl);

    return req;
  }
  private getTempData() {
    let tempItems = [];

    for (let i = 0; i < 15; i++) {
      let temp = new Item();
      temp.id = Math.random() * 6 + 1;
      temp.image =
        "https://images-na.ssl-images-amazon.com/images/I/61ptzNC8r8L._SL1500_.jpg";
      temp.name = "Some Item Name";
      temp.source = "AMAZON";
      tempItems.push(temp);
    }
    return tempItems;
  }
}
