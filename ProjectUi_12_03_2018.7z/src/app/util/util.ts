export class Util {
  public BASEURL: string = "SOME_EXAMPLE_URL";
}
