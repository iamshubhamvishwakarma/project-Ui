import { Component, OnInit, Input, ElementRef, ViewChild } from "@angular/core";
import { counter } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: "UI-item-holder",
  templateUrl: "./item-holder.component.html",
  styleUrls: ["./item-holder.component.scss"]
})
export class ItemHolderComponent implements OnInit {
  @ViewChild("horidiv") horiDiv: ElementRef;

  @Input()
  items;
  counter = 0;
  constructor() {}

  ngOnInit() {}
  scrolled($event) {
    console.log($event);
    $event.path[1].window.pageXOffset += 10;
  }
  scrollRight(event) {
    this.counter++;
    this.horiDiv.nativeElement.scrollLeft+100;
  }
  scrollLeft(event) {
    this.counter--;
    console.log(event);
  }
}
