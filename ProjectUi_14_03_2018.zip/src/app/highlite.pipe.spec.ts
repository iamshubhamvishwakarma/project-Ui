import { HighlitePipe } from './highlite.pipe';

describe('HighlitePipe', () => {
  it('create an instance', () => {
    const pipe = new HighlitePipe();
    expect(pipe).toBeTruthy();
  });
});
