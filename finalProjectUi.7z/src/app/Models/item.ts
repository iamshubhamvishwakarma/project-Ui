
export class Item {
    id:any;
    name:string;
    price: number;
    source: string;
    image: string;
  }
  