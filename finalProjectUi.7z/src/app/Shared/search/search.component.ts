import { Component, OnInit } from "@angular/core";

@Component({
  selector: "UI-search",
  templateUrl: "./search.component.html",
  styleUrls: ["./search.component.scss"]
})
export class SearchComponent implements OnInit {
  constructor() {}
  historys: any = [];
  ngOnInit() {
    for (let index = 0; index < 10; index++) {
      this.historys.push("This is test history");
    }
  }

  HasFocus($event) {
    console.log($event);
  }
  hadFocus($event) {
    console.log($event);
  }
}
