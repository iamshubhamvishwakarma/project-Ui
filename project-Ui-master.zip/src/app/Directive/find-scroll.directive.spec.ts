import { FindScrollDirective } from './find-scroll.directive';

describe('FindScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new FindScrollDirective();
    expect(directive).toBeTruthy();
  });
});
