import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'UI-banners',
  templateUrl: './banners.component.html',
  styleUrls: ['./banners.component.scss']
})
export class BannersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
