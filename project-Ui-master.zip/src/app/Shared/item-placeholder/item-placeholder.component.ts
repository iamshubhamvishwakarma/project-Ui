import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'UI-item-placeholder',
  templateUrl: './item-placeholder.component.html',
  styleUrls: ['./item-placeholder.component.scss']
})
export class ItemPlaceholderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
