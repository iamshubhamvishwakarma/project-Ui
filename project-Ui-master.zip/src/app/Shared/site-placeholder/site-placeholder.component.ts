import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'UI-site-placeholder',
  templateUrl: './site-placeholder.component.html',
  styleUrls: ['./site-placeholder.component.scss']
})
export class SitePlaceholderComponent implements OnInit {

  constructor() {console.log("something"); }
 
  ngOnInit() {
    
  }

}
