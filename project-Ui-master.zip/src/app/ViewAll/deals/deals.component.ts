import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'UI-deals',
  templateUrl: './deals.component.html',
  styleUrls: ['./deals.component.scss']
})
export class DealsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
