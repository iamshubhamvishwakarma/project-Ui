import { Component, OnInit, Input } from "@angular/core";

@Component({
  selector: "UI-message",
  templateUrl: "./message.component.html",
  styleUrls: ["./message.component.scss"]
})
export class MessageComponent implements OnInit {
  @Input() data;
  now:number;
  constructor() {
    this.now = Date.now()
  }

  ngOnInit() {}
}
