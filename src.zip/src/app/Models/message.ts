export class Message {
  isFromMe: boolean;
  message: any;
  isfavourite: boolean;
  
}
