import { Component } from '@angular/core';

@Component({
  selector: 'UI-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ProjectUi';
}
