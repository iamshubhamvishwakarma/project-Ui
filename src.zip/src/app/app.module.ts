import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { SliderComponent } from "./Slider/slider/slider.component";
import { BotComponent } from "./Bot/bot/bot.component";
import { WindowComponent } from "./Bot/window/window.component";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { FormsModule } from "@angular/forms";
import { MessageComponent } from "./Bot/message/message.component";
import { FilterPipe } from './filter.pipe';
@NgModule({
  declarations: [
    AppComponent,
    SliderComponent,
    BotComponent,
    WindowComponent,
    MessageComponent,
    FilterPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
